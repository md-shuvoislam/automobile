<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Gutenberg
 */
class WPBakeryShortCode_Vc_Gutenberg extends WPBakeryShortCode {
	/**
	 * @param $title
	 * @return string
	 */
	protected function outputTitle( $title ) {
		return '';
	}
}
